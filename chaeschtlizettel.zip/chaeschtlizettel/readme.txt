=== Chäschtlizettel ===
Contributors: Matthias Kunz
Donate link:
Tags:
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 0.1

Provides Information for Meetingpoints in YMCA Scouting

== Description ==

Provides Information for Meetingpoints in YMCA Scouting

== Installation ==


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 1.2 =
-  New data row stufe.email for simple deregistration of participant from next program.

= 1.0 =
- First release

= 0.4 =
- Initial Revision
- New data rows stufe.abteilung, stufe.jahrgang, chaeschlizettel.mitnehmen

= 0.1 =
- Initial Revision